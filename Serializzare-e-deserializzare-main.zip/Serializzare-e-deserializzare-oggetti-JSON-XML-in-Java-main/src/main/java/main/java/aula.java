package main.java;

public class aula {
    String nome;
    int numeroDiBanchi;

    public aula() {
    }


    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumeroDiBanchi() {
        return this.numeroDiBanchi;
    }

    public void setNumeroDiBanchi(int numeroDiBanchi) {
        this.numeroDiBanchi = numeroDiBanchi;
    }
}
