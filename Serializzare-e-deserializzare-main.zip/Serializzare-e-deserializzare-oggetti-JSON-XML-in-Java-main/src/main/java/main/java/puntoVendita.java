package main.java;

import java.util.ArrayList;
public class puntoVendita {
    public int size;
    public ArrayList<ListaRisultati> listaRisultati;

    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public ArrayList<ListaRisultati> getListaRisultati() {
        return this.listaRisultati;
    }

    public void setListaRisultati(ArrayList<ListaRisultati> listaRisultati) {
        this.listaRisultati = listaRisultati;
    }

}
